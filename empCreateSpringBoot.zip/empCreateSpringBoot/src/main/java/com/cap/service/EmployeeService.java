package com.cap.service;

import java.util.List;

import com.cap.entities.Employee;

public interface EmployeeService {
	
	List<Employee> createEmployee(Employee emp);

}
